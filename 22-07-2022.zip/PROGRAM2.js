function alertEX(){
    alert("AND ARE YOU VACINATED");
}
function confirmEX(){
    {
        if(confirm("YOUR PRODUCTS ARE AVILABLE IN THIS SHOP!")){
            alert("YES");
        }
        else{
            alert("NO");
            alert("SORRY FOR THIS SIR..")
        }
    }
    
}
function PromptEX(){
    var Name=prompt("ENTER YOUR NAME");
    var BName=prompt("ENTER YOUR BRAND OF PRODUCTS");
    alert(Name+" "+"YOU ARE BUYING"+" "+BName+" "+"PRODUCTS");
}